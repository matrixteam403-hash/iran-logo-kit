# Persian Labs – Iranian brand logos (export)

Source: @persianlabs/icons (MIT). SVG + 512px transparent PNG for each of 834 marks. See manifest.csv.
