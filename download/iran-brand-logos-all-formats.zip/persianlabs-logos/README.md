# Persian Labs – Iranian brand logos (export)

Source: https://icons.persian-labs.ir (npm: @persianlabs/icons v1.0.4)
License: MIT (see LICENSE)

- svg/<category>/<color|mono>/<brand>.svg  – original vector files (834)
- png/<category>/<color|mono>/<brand>.png  – 512×512 transparent PNG rasters (834)
- manifest.csv – index of every logo (category, variant, brand, paths)

Each brand exists in a `color` and a `mono` version.
